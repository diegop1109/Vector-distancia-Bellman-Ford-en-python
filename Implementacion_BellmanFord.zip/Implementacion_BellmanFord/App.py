#importamos las clases que utilizaremos para la ejecucion del programa
from Algoritmo import Algoritmo
from Arista import Arista
from Nodo import Nodo




'''TOPOLOGÍA 2'''
#actualmente esta implementacion corresponde a la topología 3 señalada en el reporte tecnico
#los vertices del grafo, llaman a la clase nodo donde se han definido los atributos de cada nodo/vertice
nodo1 = Nodo("A")
nodo2 = Nodo("B")
nodo3 = Nodo("C")
nodo4 = Nodo("D")
nodo5 = Nodo("E")
nodo6 = Nodo("F")

#las aristas de los vertices del grafo
arista1 = Arista(15, nodo1, nodo4)
arista2 = Arista(17, nodo1, nodo6)
arista3 = Arista(5, nodo2, nodo1)
arista4 = Arista(10, nodo2, nodo5)
arista5 = Arista(8, nodo3, nodo1)
arista6 = Arista(3, nodo4, nodo2)
arista7 = Arista(20, nodo5, nodo6)
arista8 = Arista(2, nodo6, nodo3)

#listas de adyacencia de cada nodo/vetice
#lista de adyacencias del nodo1(A)
nodo1.listaAdyacencias.append(arista1)
nodo1.listaAdyacencias.append(arista2)

#lista de adyacencias del nodo2(B)
nodo2.listaAdyacencias.append(arista3)
nodo2.listaAdyacencias.append(arista4)

#lista de adyacencias del nodo3(C)
nodo3.listaAdyacencias.append(arista5)

#lista de adyacencias del nodo4(D)
nodo4.listaAdyacencias.append(arista6)

#lista de adyacencias del nodo5(E)
nodo5.listaAdyacencias.append(arista7)

#lista de adyacencias del nodo6(F)
nodo6.listaAdyacencias.append(arista8)


#lista de vertices y aristas disponibles en el grafo 
#ambas listas indican que vertices y aristas EXISTEN DENTRO DE LA TOPOLOGÍA
vertices = [nodo1, nodo2, nodo3, nodo4, nodo5, nodo6]
aristas = [arista1, arista2, arista3, arista4, arista5, arista6, arista7, arista8]




'''TOPOLOGÍA 3'''
'''
#actualmente esta implementacion corresponde a la topología 3 señalada en el reporte tecnico
#los vertices del grafo, llaman a la clase nodo donde se han definido los atributos de cada nodo/vertice
nodo1 = Nodo("A")
nodo2 = Nodo("B")
nodo3 = Nodo("C")
nodo4 = Nodo("D")
nodo5 = Nodo("E")
nodo6 = Nodo("F")

#las aristas de los vertices del grafo
arista1 = Arista(15, nodo1, nodo4)
arista2 = Arista(-17, nodo1, nodo6)
arista3 = Arista(-5, nodo2, nodo1)
arista4 = Arista(-10, nodo2, nodo5)
arista5 = Arista(-8, nodo3, nodo1)
arista6 = Arista(-3, nodo4, nodo2)
arista7 = Arista(-20, nodo5, nodo6)
arista8 = Arista(2, nodo6, nodo3)

#listas de adyacencia de cada nodo/vetice
#lista de adyacencias del nodo1(A)
nodo1.listaAdyacencias.append(arista1)
nodo1.listaAdyacencias.append(arista2)

#lista de adyacencias del nodo2(B)
nodo2.listaAdyacencias.append(arista3)
nodo2.listaAdyacencias.append(arista4)

#lista de adyacencias del nodo3(C)
nodo3.listaAdyacencias.append(arista5)

#lista de adyacencias del nodo4(D)
nodo4.listaAdyacencias.append(arista6)

#lista de adyacencias del nodo5(E)
nodo5.listaAdyacencias.append(arista7)

#lista de adyacencias del nodo6(F)
nodo6.listaAdyacencias.append(arista8)


#lista de vertices y aristas disponibles en el grafo 
#ambas listas indican que vertices y aristas EXISTEN DENTRO DE LA TOPOLOGÍA
vertices = [nodo1, nodo2, nodo3, nodo4, nodo5, nodo6]
aristas = [arista1, arista2, arista3, arista4, arista5, arista6, arista7, arista8]
'''


#inicialiar la implementacion de Bellman-Ford
bellman = Algoritmo()

#iterar para todo los vertices
for i in vertices:
    bellman.CalcularRutaMasCorta(vertices, aristas, nodo4)
    bellman.getRutaMasCorta(i) 