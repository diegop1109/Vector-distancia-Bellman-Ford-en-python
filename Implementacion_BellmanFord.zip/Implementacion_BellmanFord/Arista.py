#clase que representa a la arista formada entre un vertice con otro


class Arista(object):

    #vertice de ORIGEN tiene un PESO en su arista que va hacia el vertice DESTINO
    def __init__(self, peso, origen, destino):

        #peso de la arista
        self.peso = peso

        #nodo de origen de la arista
        self.origen = origen

        #nodo destino de la arista
        self.destino = destino