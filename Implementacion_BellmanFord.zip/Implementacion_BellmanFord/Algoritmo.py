
#aqui se implementara el algoritmo de bellman-ford

class Algoritmo(object):

    #variable con la que se evaluara si ya se ha realizado un primer ciclo con carga negativa
    ciclo_negativo = False

    #metodo para obtener la ruta mas corta del origen con respecto a la lista de vertices
    def CalcularRutaMasCorta(self, listaVer, ListaAr, origen):
        #el nodo de origen siempre tendra una distancia/peso de 0
        origen.minDis = 0
        
        #recorrer las aristas mediante el numero de vertices existentes
        for i in range(0, len(listaVer) - 1):
            for arista in ListaAr:
                #tomamos el origen y destino de la arista
                #por lo que ahora "a" y "b" son nodos
                a = arista.origen
                b = arista.destino

                #la nueva distancia tomara la distancia del origen y el peso de la arista
                nuevaDistancia = a.minDis + arista.peso 
                # Ejemplos:
                #   NUEVA DISTANCIA = 11 + 25 = 36

                #calculamos si la distancia obtenida anteriormente es menor a la distancia del destino de la arista
                if nuevaDistancia < b.minDis:
                    b.minDis = nuevaDistancia
                    b.Anterior = a

        #iteracion para, por cada arista, buscar aquellas que devuelvan un ciclo negativo
        for arista in ListaAr:
            #arista ingresa al metodo "ciclo"
            if self.Ciclo(arista):
                print("ciclo negativo detectado...")
                Algoritmo.ciclo_negativo = True
                return
    
    #metodo ciclo evalua si hay o no un ciclo negativo
    def Ciclo(self, arista):
        #si la distancia de destino (minDis) es mayor a la distancia del origen mas el peso de la arista
        if arista.origen.minDis + arista.peso < arista.destino.minDis:
            return True 
        else:
            return False

    #metodo para devolver por pantalla la ruta calculada
    def getRutaMasCorta(self, destino):

        if not Algoritmo.ciclo_negativo:         #si hay ciclo negativo, no entrar 

            #imprimir la distancia hacia el nodo destino
            print("distancia mas corta: ", destino.minDis)

            nodo = destino

            print("recorrido: ")

            #imprime el recorrido desde el nodo de origen hacia el destino
            while nodo is not None:
                print("%s ->"%(nodo.nombre))
                nodo =  nodo.Anterior