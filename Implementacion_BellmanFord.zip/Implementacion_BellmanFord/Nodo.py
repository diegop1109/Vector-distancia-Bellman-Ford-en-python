# clase que representa la estructura de los vertices como un nodo

import sys

class Nodo(object):

    def __init__(self,nombre):
        self.nombre = nombre        #nombre del nodo/vertice
        self.listaAdyacencias = []      #aristas del nodo/vertice
        self.Anterior = None        #indica el nodo/vertice anterior al destino
        self.minDis = sys.maxsize #maxsize asigna el maximo valor posible a asignar por el sistema (representa "infinito") para aquellos nodos que aun no han sido visitados